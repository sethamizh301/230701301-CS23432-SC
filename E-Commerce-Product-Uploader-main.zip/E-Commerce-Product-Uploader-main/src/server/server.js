
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const xlsx = require('xlsx');
const csv = require('csv-parser');
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Create uploads directory if it doesn't exist
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer for file storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === 'productFile' || file.fieldname === 'image') {
      cb(null, uploadDir);
    } else {
      cb(new Error('Invalid field name'), false);
    }
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

// File filter function to validate file types
const fileFilter = (req, file, cb) => {
  if (file.fieldname === 'productFile') {
    // For CSV or Excel files
    if (file.mimetype === 'text/csv' || 
        file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        file.mimetype === 'application/vnd.ms-excel') {
      cb(null, true);
    } else {
      cb(new Error('Only CSV or Excel files are allowed!'), false);
    }
  } else if (file.fieldname === 'image') {
    // For image files
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
      cb(null, true);
    } else {
      cb(new Error('Only JPG and PNG image files are allowed!'), false);
    }
  } else {
    cb(new Error('Unknown fieldname'), false);
  }
};

const upload = multer({ 
  storage: storage,
  fileFilter: fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// In-memory data store
let products = [];

// Image hash storage to detect duplicate images
const imageHashes = new Map();

// Helper function to generate hash for an image file
const generateImageHash = (filePath) => {
  const fileBuffer = fs.readFileSync(filePath);
  return crypto.createHash('md5').update(fileBuffer).digest('hex');
};

// Helper function to check if an image is a duplicate by content
const isDuplicateImage = (filePath, excludeProductId = null) => {
  try {
    const hash = generateImageHash(filePath);
    const existingProduct = imageHashes.get(hash);
    
    if (existingProduct && existingProduct !== excludeProductId) {
      return true;
    }
    
    if (!existingProduct) {
      // If it's a new image (not updating), store its hash
      if (!excludeProductId) {
        imageHashes.set(hash, true);
      }
    }
    
    return false;
  } catch (error) {
    console.error('Error checking duplicate image:', error);
    return false;
  }
};

// Helper function to check if an image name is already used
const isImageNameUnique = (imageName, excludeProductId = null) => {
  return !products.some(product => 
    product.image === imageName && (excludeProductId === null || product.id !== excludeProductId)
  );
};

// Helper function to validate product data
const validateProduct = (product) => {
  const errors = [];
  
  if (!product.name || product.name.trim() === '') {
    errors.push('Product name is required');
  }
  
  if (!product.description || product.description.trim() === '') {
    errors.push('Product description is required');
  }
  
  if (!product.price) {
    errors.push('Product price is required');
  } else if (isNaN(parseFloat(product.price)) || parseFloat(product.price) <= 0) {
    errors.push('Product price must be a positive number');
  }
  
  if (product.image && typeof product.image === 'string' && product.image.match(/^https?:\/\//i)) {
    errors.push('Image URLs are not allowed, please upload an image file');
  }
  
  return errors;
};

// Basic content filter for image names (simulated)
const containsInappropriateContent = (filename) => {
  const inappropriateKeywords = ['adult', 'explicit', 'nsfw', 'xxx', 'nude'];
  const lowercaseFilename = filename.toLowerCase();
  return inappropriateKeywords.some(keyword => lowercaseFilename.includes(keyword));
};

// Routes
// Get all products with pagination and search
app.get('/api/products', (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const search = req.query.search ? req.query.search.toLowerCase() : '';
    const minPrice = req.query.minPrice ? parseFloat(req.query.minPrice) : null;
    const maxPrice = req.query.maxPrice ? parseFloat(req.query.maxPrice) : null;
    
    let filteredProducts = [...products];
    
    // Apply search filter
    if (search) {
      filteredProducts = filteredProducts.filter(product => 
        product.name.toLowerCase().includes(search) || 
        product.description.toLowerCase().includes(search)
      );
    }
    
    // Apply price range filter if specified
    if (minPrice !== null) {
      filteredProducts = filteredProducts.filter(product => product.price >= minPrice);
    }
    
    if (maxPrice !== null) {
      filteredProducts = filteredProducts.filter(product => product.price <= maxPrice);
    }
    
    // Sort products (newest first)
    filteredProducts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    
    const results = {
      totalProducts: filteredProducts.length,
      totalPages: Math.ceil(filteredProducts.length / limit),
      currentPage: page,
      products: filteredProducts.slice(startIndex, endIndex)
    };
    
    res.json(results);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get a single product by ID
app.get('/api/products/:id', (req, res) => {
  try {
    const product = products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create a new product with image upload
app.post('/api/products', upload.single('image'), (req, res) => {
  try {
    const productData = {
      name: req.body.name,
      description: req.body.description,
      price: req.body.price
    };
    
    // Validate product data
    const errors = validateProduct(productData);
    if (errors.length > 0) {
      // Remove uploaded file if validation fails
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(400).json({ errors });
    }
    
    // Check if uploaded file exists
    if (!req.file) {
      return res.status(400).json({ errors: ['Product image is required'] });
    }
    
    // Check for inappropriate content
    if (containsInappropriateContent(req.file.originalname)) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ errors: ['Image filename contains inappropriate content'] });
    }
    
    // Check for duplicate image content
    if (isDuplicateImage(req.file.path)) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ errors: ['This image is already used for another product'] });
    }
    
    const newProduct = {
      id: uuidv4(),
      name: productData.name,
      description: productData.description,
      price: parseFloat(productData.price),
      image: req.file.filename,
      createdAt: new Date().toISOString()
    };
    
    // Store the image hash with the product ID
    const hash = generateImageHash(req.file.path);
    imageHashes.set(hash, newProduct.id);
    
    products.push(newProduct);
    res.status(201).json(newProduct);
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update a product
app.put('/api/products/:id', upload.single('image'), (req, res) => {
  try {
    const productIndex = products.findIndex(p => p.id === req.params.id);
    if (productIndex === -1) {
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(404).json({ message: 'Product not found' });
    }
    
    const existingProduct = products[productIndex];
    const updatedProduct = {
      ...existingProduct,
      name: req.body.name || existingProduct.name,
      description: req.body.description || existingProduct.description,
      price: req.body.price ? parseFloat(req.body.price) : existingProduct.price
    };
    
    // Validate updated product data
    const errors = validateProduct(updatedProduct);
    if (errors.length > 0) {
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(400).json({ errors });
    }
    
    // Handle image update if a new file is uploaded
    if (req.file) {
      // Check for inappropriate content
      if (containsInappropriateContent(req.file.originalname)) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ errors: ['Image filename contains inappropriate content'] });
      }
      
      // Check for duplicate image content
      if (isDuplicateImage(req.file.path, existingProduct.id)) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ errors: ['This image is already used for another product'] });
      }
      
      // Delete old image file if it exists
      if (existingProduct.image) {
        const oldImagePath = path.join(uploadDir, existingProduct.image);
        if (fs.existsSync(oldImagePath)) {
          fs.unlinkSync(oldImagePath);
          
          // Remove old hash
          for (const [hash, prodId] of imageHashes.entries()) {
            if (prodId === existingProduct.id) {
              imageHashes.delete(hash);
              break;
            }
          }
        }
      }
      
      updatedProduct.image = req.file.filename;
      
      // Store new hash
      const hash = generateImageHash(req.file.path);
      imageHashes.set(hash, existingProduct.id);
    }
    
    products[productIndex] = updatedProduct;
    res.json(updatedProduct);
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Delete a product
app.delete('/api/products/:id', (req, res) => {
  try {
    const productIndex = products.findIndex(p => p.id === req.params.id);
    if (productIndex === -1) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    const product = products[productIndex];
    
    // Delete image file if it exists
    if (product.image) {
      const imagePath = path.join(uploadDir, product.image);
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
        
        // Remove hash from storage
        for (const [hash, prodId] of imageHashes.entries()) {
          if (prodId === product.id) {
            imageHashes.delete(hash);
            break;
          }
        }
      }
    }
    
    products.splice(productIndex, 1);
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Bulk upload products via CSV or Excel file
app.post('/api/products/bulk', upload.single('productFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ errors: ['Please upload a CSV or Excel file'] });
    }
    
    const filePath = req.file.path;
    const fileExt = path.extname(req.file.originalname).toLowerCase();
    const successProducts = [];
    const failedProducts = [];
    
    // Process CSV file
    if (fileExt === '.csv') {
      const rows = [];
      await new Promise((resolve, reject) => {
        fs.createReadStream(filePath)
          .pipe(csv())
          .on('data', (row) => rows.push(row))
          .on('end', () => resolve())
          .on('error', (error) => reject(error));
      });
      
      for (const row of rows) {
        const product = {
          name: row.name,
          description: row.description,
          price: row.price,
          image: row.image || ''
        };
        
        const validationErrors = validateProduct(product);
        
        // Check if the image is a URL or if it's a file that doesn't exist in the upload directory
        if (product.image) {
          if (product.image.match(/^https?:\/\//i)) {
            validationErrors.push('Image URLs are not allowed, please upload an image file');
          } else {
            // Check if the image file exists in the uploads directory
            const imagePath = path.join(uploadDir, product.image);
            if (!fs.existsSync(imagePath)) {
              validationErrors.push(`Image file ${product.image} not found in the uploads directory`);
            } else if (isDuplicateImage(imagePath)) {
              validationErrors.push('This image is already used for another product');
            }
          }
        } else {
          validationErrors.push('Product image is required');
        }
        
        if (validationErrors.length > 0) {
          failedProducts.push({
            data: product,
            errors: validationErrors
          });
        } else {
          const newProduct = {
            id: uuidv4(),
            name: product.name,
            description: product.description,
            price: parseFloat(product.price),
            image: product.image,
            createdAt: new Date().toISOString()
          };
          
          // Store the image hash with the product ID
          const imagePath = path.join(uploadDir, product.image);
          const hash = generateImageHash(imagePath);
          imageHashes.set(hash, newProduct.id);
          
          products.push(newProduct);
          successProducts.push(newProduct);
        }
      }
    } 
    // Process Excel file
    else if (fileExt === '.xlsx' || fileExt === '.xls') {
      const workbook = xlsx.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const data = xlsx.utils.sheet_to_json(sheet);
      
      for (const row of data) {
        const product = {
          name: row.name,
          description: row.description,
          price: row.price,
          image: row.image || ''
        };
        
        const validationErrors = validateProduct(product);
        
        // Check if the image is a URL or if it's a file that doesn't exist in the upload directory
        if (product.image) {
          if (product.image.match(/^https?:\/\//i)) {
            validationErrors.push('Image URLs are not allowed, please upload an image file');
          } else {
            // Check if the image file exists in the uploads directory
            const imagePath = path.join(uploadDir, product.image);
            if (!fs.existsSync(imagePath)) {
              validationErrors.push(`Image file ${product.image} not found in the uploads directory`);
            } else if (isDuplicateImage(imagePath)) {
              validationErrors.push('This image is already used for another product');
            }
          }
        } else {
          validationErrors.push('Product image is required');
        }
        
        if (validationErrors.length > 0) {
          failedProducts.push({
            data: product,
            errors: validationErrors
          });
        } else {
          const newProduct = {
            id: uuidv4(),
            name: product.name,
            description: product.description,
            price: parseFloat(product.price),
            image: product.image,
            createdAt: new Date().toISOString()
          };
          
          // Store the image hash with the product ID
          const imagePath = path.join(uploadDir, product.image);
          const hash = generateImageHash(imagePath);
          imageHashes.set(hash, newProduct.id);
          
          products.push(newProduct);
          successProducts.push(newProduct);
        }
      }
    }
    
    // Delete the temporary file
    fs.unlinkSync(filePath);
    
    res.json({
      success: successProducts.length,
      failed: failedProducts.length,
      successProducts,
      failedProducts
    });
  } catch (error) {
    console.error('Error processing bulk upload:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get a sample CSV template
app.get('/api/template/csv', (req, res) => {
  const csvContent = 'name,description,price,image\nSample Product,This is a sample product,19.99,leave_blank_to_upload_later.jpg';
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=product_template.csv');
  res.send(csvContent);
});

// Get a sample Excel template
app.get('/api/template/excel', (req, res) => {
  const data = [
    { name: 'Sample Product', description: 'This is a sample product', price: 19.99, image: 'leave_blank_to_upload_later.jpg' }
  ];
  
  const worksheet = xlsx.utils.json_to_sheet(data);
  const workbook = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(workbook, worksheet, 'Products');
  
  const buffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=product_template.xlsx');
  res.send(buffer);
});

// Get server status endpoint for health checks
app.get('/api/status', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Server error:', err.stack);
  res.status(err.status || 500).json({
    message: err.message || 'An unexpected error occurred',
    error: process.env.NODE_ENV === 'development' ? err.stack : {}
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
