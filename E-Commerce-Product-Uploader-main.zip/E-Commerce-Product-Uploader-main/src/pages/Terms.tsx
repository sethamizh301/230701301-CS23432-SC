import React from "react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Footer from "../components/layout/Footer";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      when: "beforeChildren",
      staggerChildren: 0.1,
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 300, damping: 24 }
  }
};

const Terms = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col min-h-screen">
      <motion.div
        className="flex-grow bg-gradient-to-b from-gray-50 to-gray-100 py-12 px-4 sm:px-6 lg:px-8"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6 sm:p-8">
          <motion.div variants={itemVariants} className="mb-6 flex items-center">
            <Button 
              variant="ghost" 
              onClick={() => navigate(-1)} 
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">Terms of Service</h1>
          </motion.div>

          <motion.div variants={itemVariants} className="prose max-w-none">
            <p className="text-lg mb-6">
              Last updated: April 21, 2025
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">1. Introduction</h2>
            <p>
              Welcome to the E-commerce Product Uploader. These Terms of Service ("Terms") govern your use of our website and services. By accessing or using our service, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access the service.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">2. Use License</h2>
            <p>
              Permission is granted to temporarily use this software and website for personal or commercial purposes, provided you adhere to these Terms of Service. This license shall automatically terminate if you violate any of these restrictions and may be terminated by the E-commerce Product Uploader at any time.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">3. User Account</h2>
            <p>
              When you create an account with us, you must provide information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.
            </p>
            <p>
              You are responsible for safeguarding the password you use to access the Service and for any activities or actions under your password. You agree not to disclose your password to any third party.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">4. Products</h2>
            <p>
              You agree not to upload products that violate copyright, trademark, or other intellectual property rights. You must have proper authorization to sell all products listed through our platform.
            </p>
            <p>
              All product information must be accurate, truthful, and compliant with applicable laws and regulations. Products that violate our policies may be removed without notice.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">5. Disclaimer</h2>
            <p>
              The materials on the E-commerce Product Uploader website are provided on an 'as is' basis. The E-commerce Product Uploader makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">6. Limitations</h2>
            <p>
              In no event shall the E-commerce Product Uploader or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on the website, even if the E-commerce Product Uploader or an authorized representative has been notified orally or in writing of the possibility of such damage.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">7. Governing Law</h2>
            <p>
              These Terms shall be governed and construed in accordance with the laws, without regard to its conflict of law provisions. Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">8. Changes to Terms</h2>
            <p>
              We reserve the right, at our sole discretion, to modify or replace these Terms at any time. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">9. Contact Us</h2>
            <p>
              If you have any questions about these Terms, please contact us at support@ecommerce-uploader.com.
            </p>
          </motion.div>
        </div>
      </motion.div>
      <Footer />
    </div>
  );
};

export default Terms;
