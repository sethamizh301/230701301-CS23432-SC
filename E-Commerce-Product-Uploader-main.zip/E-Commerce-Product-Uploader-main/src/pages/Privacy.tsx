import React from "react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Footer from "../components/layout/Footer";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      when: "beforeChildren",
      staggerChildren: 0.1,
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 300, damping: 24 }
  }
};

const Privacy = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col min-h-screen">
      <motion.div
        className="flex-grow bg-gradient-to-b from-gray-50 to-gray-100 py-12 px-4 sm:px-6 lg:px-8"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6 sm:p-8">
          <motion.div variants={itemVariants} className="mb-6 flex items-center">
            <Button 
              variant="ghost" 
              onClick={() => navigate(-1)} 
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">Privacy Policy</h1>
          </motion.div>

          <motion.div variants={itemVariants} className="prose max-w-none">
            <p className="text-lg mb-6">
              Last updated: April 21, 2025
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">1. Introduction</h2>
            <p>
              At E-commerce Product Uploader, we respect your privacy and are committed to protecting it through our compliance with this policy. This Privacy Policy describes the types of information we may collect from you or that you may provide when you visit our website and our practices for collecting, using, maintaining, protecting, and disclosing that information.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">2. Information We Collect</h2>
            <p>
              We collect several types of information from and about users of our website, including:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Personal identifiers such as name and email address when you create an account</li>
              <li>Information about your business and products when you use our services</li>
              <li>Usage details, IP addresses, and information collected through cookies and other tracking technologies</li>
              <li>Images and content you upload to our platform</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-4">3. How We Use Your Information</h2>
            <p>
              We use information that we collect about you or that you provide to us:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>To present our website and its contents to you</li>
              <li>To provide you with information, products, or services that you request from us</li>
              <li>To fulfill any other purpose for which you provide it</li>
              <li>To carry out our obligations and enforce our rights</li>
              <li>To notify you about changes to our service or products</li>
              <li>To improve our website and services</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-4">4. Data Security</h2>
            <p>
              We have implemented measures designed to secure your personal information from accidental loss and from unauthorized access, use, alteration, and disclosure. All information you provide to us is stored on secure servers behind firewalls.
            </p>
            <p>
              Unfortunately, the transmission of information via the internet is not completely secure. Although we do our best to protect your personal information, we cannot guarantee the security of your personal information transmitted to our website. Any transmission of personal information is at your own risk.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">5. Your Rights</h2>
            <p>
              You have the right to:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Access and receive a copy of the personal data we hold about you</li>
              <li>Rectify any personal data held about you that is inaccurate</li>
              <li>Request the deletion of personal data held about you</li>
              <li>Restrict the processing of your personal data</li>
              <li>Request that we transfer your personal data to you or to another service provider</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-4">6. Cookies</h2>
            <p>
              Our website uses cookies to enhance your experience. You can set your browser to refuse all or some browser cookies, or to alert you when cookies are being sent. If you disable or refuse cookies, please note that some parts of this site may then be inaccessible or not function properly.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">7. Children's Privacy</h2>
            <p>
              Our Services are not intended for children under 16 years of age. No one under age 16 may provide any information to or on the Website. We do not knowingly collect personal information from children under 16.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">8. Changes to Our Privacy Policy</h2>
            <p>
              It is our policy to post any changes we make to our privacy policy on this page. If we make material changes to how we treat our users' personal information, we will notify you through a notice on the Website. The date the privacy policy was last revised is identified at the top of the page.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-4">9. Contact Information</h2>
            <p>
              To ask questions or comment about this privacy policy and our privacy practices, contact us at privacy@ecommerce-uploader.com.
            </p>
          </motion.div>
        </div>
      </motion.div>
      <Footer />
    </div>
  );
};

export default Privacy;
