
import React, { useState, useEffect, useRef } from "react";
import { toast } from "@/components/ui/use-toast";
import ProductList from "@/components/product/ProductList";
import ProductForm from "@/components/product/ProductForm";
import BulkUploadForm from "@/components/product/BulkUploadForm";
import SearchBar from "@/components/product/SearchBar";
import Pagination from "@/components/product/Pagination";
import { Product } from "@/types/product";
import { PlusCircle, Package } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import UserProfile from "@/components/auth/UserProfile";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import Footer from "@/components/layout/Footer";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      when: "beforeChildren",
      staggerChildren: 0.1,
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 300, damping: 24 }
  }
};

const Index = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [activeTab, setActiveTab] = useState<string>("products");
  const [refreshKey, setRefreshKey] = useState<number>(0);
  
  const { user } = useAuth();
  const productListRef = useRef<HTMLDivElement>(null);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      
      const from = (currentPage - 1) * 10;
      const to = from + 9;
      
      // Use any type assertion to bypass TypeScript's deep type checking
      let query = supabase.from('products').select('*', { count: 'exact' }) as any;
      
      if (searchQuery) {
        query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
      }
      
      if (user) {
        query.eq('created_by', user.id);
      }
      
      query.range(from, to);
      query.order('created_at', { ascending: false });
      
      const result = await query;
      const { data, count, error } = result;

      if (error) throw error;

      // Debug logging
      console.log("Fetched products:", data);
      
      const productData: Product[] = data ? 
        (Array.isArray(data) ? data as Product[] : []) : [];
        
      setProducts(productData);
      setTotalPages(Math.ceil((count || 0) / 10));
      setLoading(false);
    } catch (error) {
      console.error("Error fetching products:", error);
      toast({
        title: "Error",
        description: "Failed to load products. Please try again.",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  // This effect runs when the component mounts or when dependencies change
  useEffect(() => {
    fetchProducts();
  }, [currentPage, searchQuery, refreshKey, user]);

  // Reset to first page when search query changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  // This effect runs when the active tab changes back to "products"
  useEffect(() => {
    if (activeTab === "products") {
      fetchProducts();
    }
  }, [activeTab]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    if (productListRef.current) {
      productListRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this product?")) {
      return;
    }

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Product deleted successfully",
      });
      
      setRefreshKey(prev => prev + 1);
    } catch (error) {
      console.error("Error deleting product:", error);
      toast({
        title: "Error",
        description: "Failed to delete product. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (product: Product) => {
    setEditProduct(product);
    setShowAddForm(true);
    setActiveTab("add-edit");
  };

  const handleFormSuccess = () => {
    setShowAddForm(false);
    setEditProduct(null);
    setActiveTab("products");
    setRefreshKey(prev => prev + 1);
  };

  const handleBulkUploadSuccess = () => {
    toast({
      title: "Success",
      description: "Bulk upload completed successfully",
    });
    setRefreshKey(prev => prev + 1);
    setActiveTab("products");
  };

  return (
    <motion.div 
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex flex-col"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <header className="bg-white shadow-md py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <motion.div 
            variants={itemVariants}
            className="flex items-center space-x-2"
          >
            <Package className="h-6 w-6 text-ecommerce-primary" />
            <h1 className="text-2xl font-bold text-gray-800">E-commerce Product Uploader</h1>
          </motion.div>
          <UserProfile />
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 flex-grow">
        <motion.div 
          variants={itemVariants}
          className="mb-8 text-center"
        >
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Manage Your Product Catalog</h2>
          <p className="text-gray-600">Upload, edit, and organize your products efficiently</p>
        </motion.div>

        <Tabs 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="w-full"
        >
          <motion.div 
            className="flex items-center justify-between mb-6"
            variants={itemVariants}
          >
            <TabsList className="bg-white/80 backdrop-blur-sm shadow-md">
              <TabsTrigger value="products" className="transition-all">Products</TabsTrigger>
              <TabsTrigger value="add-edit" className="transition-all">
                {editProduct ? "Edit Product" : "Add Product"}
              </TabsTrigger>
              <TabsTrigger value="bulk-upload" className="transition-all">Bulk Upload</TabsTrigger>
            </TabsList>

            <div className="flex space-x-2">
              {activeTab === "products" && (
                <Button
                  onClick={() => {
                    setEditProduct(null);
                    setShowAddForm(true);
                    setActiveTab("add-edit");
                  }}
                  className="bg-ecommerce-primary hover:bg-ecommerce-primary/90 shadow-md hover:shadow-lg transition-all duration-300"
                >
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Product
                </Button>
              )}
            </div>
          </motion.div>

          <TabsContent value="products">
            <Card className="p-6 shadow-lg border-0">
              <motion.div className="mb-6" variants={itemVariants}>
                <SearchBar onSearch={handleSearch} />
              </motion.div>
              
              <motion.div 
                ref={productListRef}
                variants={itemVariants}
              >
                <ProductList 
                  products={products} 
                  loading={loading} 
                  onEdit={handleEdit} 
                  onDelete={handleDelete} 
                />
              </motion.div>
              
              {!loading && totalPages > 0 && (
                <motion.div 
                  className="mt-6"
                  variants={itemVariants}
                >
                  <Pagination 
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                  />
                </motion.div>
              )}
              
              {!loading && products.length === 0 && (
                <motion.div 
                  className="text-center py-12"
                  variants={itemVariants}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <p className="text-gray-500 text-lg">
                    {searchQuery ? "No products match your search." : "No products yet. Add some!"}
                  </p>
                  <Button
                    onClick={() => {
                      setEditProduct(null);
                      setShowAddForm(true);
                      setActiveTab("add-edit");
                    }}
                    className="mt-4 bg-ecommerce-primary hover:bg-ecommerce-primary/90 shadow hover:shadow-lg transition-all duration-300"
                  >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Your First Product
                  </Button>
                </motion.div>
              )}
            </Card>
          </TabsContent>
          
          <TabsContent value="add-edit">
            <Card className="p-6 shadow-lg border-0">
              <ProductForm 
                product={editProduct} 
                onSuccess={handleFormSuccess} 
              />
            </Card>
          </TabsContent>
          
          <TabsContent value="bulk-upload">
            <Card className="p-6 shadow-lg border-0">
              <BulkUploadForm onSuccess={handleBulkUploadSuccess} />
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <Footer />
    </motion.div>
  );
};

export default Index;
