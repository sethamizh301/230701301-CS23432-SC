
import React, { useState, useEffect } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/components/ui/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, Mail, LogIn, LockKeyhole, User } from "lucide-react";
import { motion } from "framer-motion";

const Auth = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("login");
  const [resetSuccess, setResetSuccess] = useState(false);
  const { signIn, signUp, resetPassword, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  useEffect(() => {
    // Check if user is already signed in
    if (user) {
      navigate("/");
    }
    
    // Check if we're in password reset mode
    const hash = location.hash;
    if (hash && hash.includes("type=recovery")) {
      setActiveTab("reset-password");
    }
  }, [user, navigate, location]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error, success } = await signIn(email, password);
      
      if (error) {
        toast({
          title: "Sign In Failed",
          description: error.message,
          variant: "destructive",
        });
      } else if (success) {
        toast({
          title: "Welcome back!",
          description: "You have successfully signed in.",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error, success } = await signUp(email, password);
      
      if (error) {
        toast({
          title: "Sign Up Failed",
          description: error.message,
          variant: "destructive",
        });
      } else if (success) {
        toast({
          title: "Check your email",
          description: "We've sent you a confirmation email to verify your account.",
        });
        setActiveTab("login");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error, success } = await resetPassword(email);
      
      if (error) {
        toast({
          title: "Reset Password Failed",
          description: error.message,
          variant: "destructive",
        });
      } else if (success) {
        toast({
          title: "Check your email",
          description: "We've sent you a password reset link.",
        });
        setResetSuccess(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <motion.div 
        className="max-w-md w-full"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
      >
        <div className="text-center mb-6">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl font-bold text-ecommerce-primary mb-2">E-commerce Product Uploader</h1>
            <p className="text-gray-600">Manage your product catalog securely</p>
          </motion.div>
        </div>

        <Card className="shadow-lg border-0 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-ecommerce-primary to-ecommerce-secondary pb-6">
            <CardTitle className="text-white text-center text-2xl">
              {activeTab === "login" && "Sign In"}
              {activeTab === "register" && "Create Account"}
              {activeTab === "forgot-password" && "Reset Password"}
              {activeTab === "reset-password" && "Set New Password"}
            </CardTitle>
            <CardDescription className="text-white/80 text-center">
              {activeTab === "login" && "Welcome back! Sign in to your account"}
              {activeTab === "register" && "Create a new account to get started"}
              {activeTab === "forgot-password" && "Enter your email to reset your password"}
              {activeTab === "reset-password" && "Enter your new password"}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-2 mb-6">
                <TabsTrigger value="login">Sign In</TabsTrigger>
                <TabsTrigger value="register">Sign Up</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <form onSubmit={handleSignIn}>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="your@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10 transition-all focus:ring-2 focus:ring-ecommerce-primary/20"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="password">Password</Label>
                        <button
                          type="button"
                          className="text-xs text-ecommerce-primary hover:underline"
                          onClick={() => setActiveTab("forgot-password")}
                        >
                          Forgot password?
                        </button>
                      </div>
                      <div className="relative">
                        <LockKeyhole className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input
                          id="password"
                          type="password"
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pl-10 transition-all focus:ring-2 focus:ring-ecommerce-primary/20"
                          required
                        />
                      </div>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-ecommerce-primary to-ecommerce-secondary hover:from-ecommerce-primary/90 hover:to-ecommerce-secondary/90 shadow-md hover:shadow-lg transition-all duration-300 ease-in-out"
                      disabled={loading}
                    >
                      {loading ? (
                        <span className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Signing In...
                        </span>
                      ) : (
                        <span className="flex items-center">
                          <LogIn className="mr-2 h-4 w-4" /> Sign In
                        </span>
                      )}
                    </Button>
                  </div>
                </form>
              </TabsContent>
              
              <TabsContent value="register">
                <form onSubmit={handleSignUp}>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input
                          id="signup-email"
                          type="email"
                          placeholder="your@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10 transition-all focus:ring-2 focus:ring-ecommerce-primary/20"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Password</Label>
                      <div className="relative">
                        <LockKeyhole className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input
                          id="signup-password"
                          type="password"
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pl-10 transition-all focus:ring-2 focus:ring-ecommerce-primary/20"
                          required
                          minLength={6}
                        />
                      </div>
                      <p className="text-xs text-gray-500">Password must be at least 6 characters</p>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-ecommerce-primary to-ecommerce-secondary hover:from-ecommerce-primary/90 hover:to-ecommerce-secondary/90 shadow-md hover:shadow-lg transition-all duration-300 ease-in-out"
                      disabled={loading}
                    >
                      {loading ? (
                        <span className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Creating Account...
                        </span>
                      ) : (
                        <span className="flex items-center">
                          <User className="mr-2 h-4 w-4" /> Create Account
                        </span>
                      )}
                    </Button>
                  </div>
                </form>
              </TabsContent>
              
              <TabsContent value="forgot-password">
                {resetSuccess ? (
                  <motion.div 
                    className="text-center py-8"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="mb-4 flex justify-center">
                      <div className="rounded-full bg-green-100 p-3">
                        <Check className="h-6 w-6 text-green-600" />
                      </div>
                    </div>
                    <h3 className="text-lg font-medium">Check Your Email</h3>
                    <p className="text-gray-500 mt-2 mb-4">
                      We've sent a password reset link to your email address.
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setResetSuccess(false);
                        setActiveTab("login");
                      }}
                    >
                      Back to Sign In
                    </Button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleResetPassword}>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="reset-email">Email</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                          <Input
                            id="reset-email"
                            type="email"
                            placeholder="your@email.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="pl-10 transition-all focus:ring-2 focus:ring-ecommerce-primary/20"
                            required
                          />
                        </div>
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-gradient-to-r from-ecommerce-primary to-ecommerce-secondary hover:from-ecommerce-primary/90 hover:to-ecommerce-secondary/90 shadow-md hover:shadow-lg transition-all duration-300 ease-in-out"
                        disabled={loading}
                      >
                        {loading ? (
                          <span className="flex items-center">
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Sending...
                          </span>
                        ) : (
                          "Send Reset Link"
                        )}
                      </Button>
                      
                      <div className="text-center">
                        <button
                          type="button"
                          className="text-sm text-ecommerce-primary hover:underline"
                          onClick={() => setActiveTab("login")}
                        >
                          Back to Sign In
                        </button>
                      </div>
                    </div>
                  </form>
                )}
              </TabsContent>
              
              <TabsContent value="reset-password">
                <form>
                  {/* This will be handled automatically by Supabase */}
                  <div className="space-y-4">
                    <p className="text-sm text-gray-500">
                      Enter your new password below.
                    </p>
                    
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <div className="relative">
                        <LockKeyhole className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input
                          id="new-password"
                          type="password"
                          placeholder="••••••••"
                          className="pl-10 transition-all focus:ring-2 focus:ring-ecommerce-primary/20"
                          required
                          minLength={6}
                        />
                      </div>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-ecommerce-primary to-ecommerce-secondary hover:from-ecommerce-primary/90 hover:to-ecommerce-secondary/90 shadow-md hover:shadow-lg transition-all duration-300 ease-in-out"
                    >
                      Set New Password
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          
          <CardFooter className="flex justify-center border-t p-4">
            <p className="text-xs text-gray-500">
              By continuing, you agree to our{" "}
              <Link 
                to="/terms" 
                className="text-ecommerce-primary hover:underline transition-colors"
              >
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link 
                to="/privacy" 
                className="text-ecommerce-primary hover:underline transition-colors"
              >
                Privacy Policy
              </Link>
              .
            </p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default Auth;
