
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  created_at: string;
  updated_at: string | null;
  created_by: string | null;
  updated_by: string | null;
}

export interface ProductFormData {
  name: string;
  description: string;
  price: string;
  image?: File | null;
}

export interface BulkUploadResult {
  success: number;
  failed: number;
  successProducts: Product[];
  failedProducts: Array<{
    data: Partial<Product>;
    errors: string[];
  }>;
}
