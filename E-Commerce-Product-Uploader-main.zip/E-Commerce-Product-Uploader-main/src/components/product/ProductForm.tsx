
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Product, ProductFormData } from "@/types/product";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";

interface ProductFormProps {
  product: Product | null;
  onSuccess: () => void;
}

const productSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  description: z.string().min(1, "Product description is required"),
  price: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Price must be a positive number",
  }),
});

const ProductForm: React.FC<ProductFormProps> = ({ product, onSuccess }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(
    product?.image_url || null
  );
  const { user } = useAuth();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: product?.name || "",
      description: product?.description || "",
      price: product ? String(product.price) : "",
    },
  });

  // Check if image contains a URL
  const isImageUrl = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        // Check if the image content contains urls
        const urlRegex = /https?:\/\/[^\s"']+/i;
        resolve(urlRegex.test(result));
      };
      reader.readAsText(file);
    });
  };

  // Generate a hash for image content
  const generateImageHash = async (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        resolve(hashHex);
      };
      reader.readAsArrayBuffer(file);
    });
  };

  // Check if image already exists as another product image
  const checkDuplicateImage = async (file: File, productId?: string): Promise<boolean> => {
    try {
      // First generate a hash of the image content
      const imageHash = await generateImageHash(file);
      console.log("Generated image hash:", imageHash);
      
      // Check for duplicate images in database using the product-ops function
      const { data, error } = await supabase.functions.invoke('product-ops', {
        body: {
          action: 'check-duplicate-image',
          imageHash: imageHash,
          currentProductId: productId || null
        }
      });
      
      if (error) {
        console.error("Error checking for duplicate images:", error);
        return false; // Allow upload on error to avoid blocking users
      }
      
      console.log("Duplicate check result:", data);
      return data?.isDuplicate || false;
    } catch (error) {
      console.error("Error in checkDuplicateImage:", error);
      return false; // Allow upload on error to avoid blocking users
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!["image/jpeg", "image/png"].includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a JPG or PNG image.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Image must be less than 5MB.",
        variant: "destructive",
      });
      return;
    }

    // Check if image contains URLs
    const containsUrl = await isImageUrl(file);
    if (containsUrl) {
      toast({
        title: "Invalid image",
        description: "Images containing URLs are not allowed for security reasons.",
        variant: "destructive",
      });
      return;
    }
    
    // Check for duplicate images - more strict check
    const isDuplicate = await checkDuplicateImage(file, product?.id);
    if (isDuplicate) {
      toast({
        title: "Duplicate image",
        description: "This exact image is already used for another product. Please use a different image.",
        variant: "destructive",
      });
      e.target.value = ''; // Reset file input
      return;
    }

    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const clearImagePreview = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const onSubmit = async (data: ProductFormData) => {
    try {
      setIsSubmitting(true);

      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to create or update products",
          variant: "destructive",
        });
        return;
      }

      if (!product && !imageFile) {
        toast({
          title: "Error",
          description: "Product image is required",
          variant: "destructive",
        });
        return;
      }

      let image_url = product?.image_url;

      if (imageFile) {
        // Perform duplicate check one more time before upload
        // This helps catch race conditions in case another product was added
        const isDuplicate = await checkDuplicateImage(imageFile, product?.id);
        
        if (isDuplicate) {
          toast({
            title: "Duplicate image detected",
            description: "This image is already used for another product. Please use a different image.",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Date.now()}.${fileExt}`;
        
        const { error: uploadError, data: uploadData } = await supabase.storage
          .from('products')
          .upload(fileName, imageFile);

        if (uploadError) {
          throw new Error(uploadError.message);
        }

        if (uploadData) {
          const { data: { publicUrl } } = supabase.storage
            .from('products')
            .getPublicUrl(fileName);
          
          image_url = publicUrl;
          
          // Store the image hash in our database for future duplicate checks
          const imageHash = await generateImageHash(imageFile);
          await supabase.functions.invoke('product-ops', {
            body: {
              action: 'store-image-hash',
              imageHash: imageHash,
              productId: product?.id || 'new-product',
              imageUrl: publicUrl
            }
          });
        }
      }

      const productData = {
        name: data.name,
        description: data.description,
        price: parseFloat(data.price),
        image_url: image_url,
        created_by: user.id,
        updated_by: user.id,
      };

      let result;
      if (product) {
        // Only include updated_by in update operations
        result = await supabase
          .from('products')
          .update({
            name: data.name,
            description: data.description,
            price: parseFloat(data.price),
            image_url: image_url,
            updated_by: user.id
          })
          .eq('id', product.id)
          .select()
          .single();
      } else {
        // Include created_by in insert operations
        result = await supabase
          .from('products')
          .insert({
            name: data.name,
            description: data.description,
            price: parseFloat(data.price),
            image_url: image_url,
            created_by: user.id,
            updated_by: user.id
          })
          .select()
          .single();
      }

      if (result.error) {
        throw new Error(result.error.message);
      }

      toast({
        title: "Success",
        description: product ? "Product updated successfully" : "Product created successfully",
      });

      if (!product) {
        reset();
        setImageFile(null);
        setImagePreview(null);
      }
      
      onSuccess();
    } catch (error) {
      console.error("Error saving product:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save product",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div 
      className="max-w-2xl mx-auto"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <h2 className="text-2xl font-bold mb-6">
        {product ? "Edit Product" : "Add New Product"}
      </h2>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Product Name*</Label>
            <Input
              id="name"
              {...register("name")}
              placeholder="Product Name"
              className={`${errors.name ? "border-red-500" : ""} shadow-sm focus:ring-2 focus:ring-ecommerce-primary/20 transition-all`}
            />
            {errors.name && (
              <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="description">Description*</Label>
            <Textarea
              id="description"
              {...register("description")}
              placeholder="Product description"
              className={`min-h-[120px] ${errors.description ? "border-red-500" : ""} shadow-sm focus:ring-2 focus:ring-ecommerce-primary/20 transition-all`}
            />
            {errors.description && (
              <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="price">Price ($)*</Label>
            <Input
              id="price"
              type="text"
              {...register("price")}
              placeholder="0.00"
              className={`${errors.price ? "border-red-500" : ""} shadow-sm focus:ring-2 focus:ring-ecommerce-primary/20 transition-all`}
            />
            {errors.price && (
              <p className="text-red-500 text-sm mt-1">{errors.price.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="image">{product ? "Change Image" : "Product Image*"}</Label>
            
            {imagePreview ? (
              <motion.div 
                className="mt-2 relative w-40 h-40 border rounded overflow-hidden shadow-md"
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.2 }}
              >
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <motion.button
                  type="button"
                  className="absolute top-2 right-2 bg-black bg-opacity-50 rounded-full p-1"
                  onClick={clearImagePreview}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <X className="h-4 w-4 text-white" />
                </motion.button>
              </motion.div>
            ) : (
              <motion.div 
                whileHover={{ scale: 1.02, borderColor: "#3B82F6" }}
                transition={{ duration: 0.2 }}
              >
                <Card className="mt-2 w-full max-w-md cursor-pointer hover:bg-gray-50 border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center py-6">
                    <input
                      id="image"
                      type="file"
                      accept="image/jpeg,image/png"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                    <Upload className="h-10 w-10 text-gray-400 mb-2" />
                    <Label 
                      htmlFor="image" 
                      className="cursor-pointer text-center"
                    >
                      <span className="text-sm font-medium text-gray-900 block">
                        Click to upload
                      </span>
                      <span className="text-xs text-gray-500 block mt-1">
                        JPG or PNG (Max 5MB)
                      </span>
                    </Label>
                  </CardContent>
                </Card>
              </motion.div>
            )}
            
            {!product && !imagePreview && (
              <p className="text-red-500 text-sm mt-1">
                Product image is required
              </p>
            )}
          </div>

          <div className="flex gap-2 mt-6">
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                type="submit"
                className="bg-gradient-to-r from-ecommerce-primary to-ecommerce-secondary hover:from-ecommerce-primary/90 hover:to-ecommerce-secondary/90 shadow-md transition-all duration-300"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Saving..." : product ? "Update Product" : "Add Product"}
              </Button>
            </motion.div>
            
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                type="button"
                variant="outline"
                onClick={() => onSuccess()}
                className="shadow-sm hover:shadow transition-all duration-300"
              >
                Cancel
              </Button>
            </motion.div>
          </div>
        </div>
      </form>
    </motion.div>
  );
};

export default ProductForm;
