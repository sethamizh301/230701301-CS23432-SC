
import React from "react";
import { motion } from "framer-motion";

interface EnhancedCardProps {
  children: React.ReactNode;
  className?: string;
}

const EnhancedCard: React.FC<EnhancedCardProps> = ({ children, className = "" }) => {
  return (
    <motion.div
      className={`bg-white rounded-lg shadow-lg overflow-hidden ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      whileHover={{ y: -5, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" }}
    >
      {children}
    </motion.div>
  );
};

export default EnhancedCard;
