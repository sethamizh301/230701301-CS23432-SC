
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { toast } from "@/components/ui/use-toast";
import { AlertCircle, Check, FileSpreadsheet, Upload, X } from "lucide-react";
import { BulkUploadResult } from "@/types/product";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface BulkUploadFormProps {
  onSuccess: () => void;
}

const BulkUploadForm: React.FC<BulkUploadFormProps> = ({ onSuccess }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<BulkUploadResult | null>(null);
  const { user } = useAuth();
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const fileExt = selectedFile.name.split('.').pop()?.toLowerCase();
    if (fileExt !== 'csv') {
      toast({
        title: "Invalid file format",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      return;
    }

    setFile(selectedFile);
    setResult(null);
  };
  
  const clearFile = () => {
    setFile(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a CSV file to upload",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const formData = new FormData();
      formData.append("productFile", file);
      
      // Add the user ID to the form data
      if (user) {
        formData.append("userId", user.id);
      }
      
      const { data, error } = await supabase.functions.invoke("product-ops/products/bulk", {
        body: formData,
        method: "POST",
      });
      
      if (error) {
        console.error("Supabase function error:", error);
        throw new Error(error.message || "Failed to upload products");
      }
      
      console.log("Upload result:", data);
      setResult(data);
      
      toast({
        title: "Upload Complete",
        description: `Successfully uploaded ${data.success} products, ${data.failed} failed.`,
        variant: data.failed > 0 ? "destructive" : "default",
      });
      
      if (data.success > 0 && data.failed === 0) {
        setTimeout(() => {
          onSuccess();
        }, 1500);
      }
    } catch (error) {
      console.error("Error uploading file:", error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload products",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDownloadTemplate = async () => {
    try {
      const loadingToastId = toast({
        title: "Downloading CSV template...",
        description: "Please wait",
      });
      
      // Create a direct URL to the function endpoint
      const functionUrl = `https://xyespnksmvsgrohyzggb.supabase.co/functions/v1/product-ops/template/csv`;
      
      // Get the response using fetch for more control
      const response = await fetch(functionUrl, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`Failed to download CSV template. Status: ${response.status}`);
      }
      
      // Get the response data
      const text = await response.text();
      const blob = new Blob([text], { type: 'text/csv' });
      
      // Create a download link and trigger it
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'product_template.csv';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Download Success",
        description: "CSV template downloaded successfully",
        variant: "default",
      });
    } catch (error) {
      console.error("Error downloading CSV template:", error);
      toast({
        title: "Download failed",
        description: `Failed to download CSV template: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex flex-col lg:flex-row justify-between items-start gap-6 mb-8">
        <div>
          <h2 className="text-2xl font-bold mb-2">Bulk Upload Products</h2>
          <p className="text-gray-500 mb-4">
            Upload multiple products at once using a CSV file
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadTemplate}
            className="flex items-center"
          >
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Download CSV Template
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="mb-6">
          <Label htmlFor="fileUpload">Upload File</Label>
          
          {file ? (
            <div className="mt-2 flex items-center p-4 border rounded-md bg-gray-50">
              <FileSpreadsheet className="h-8 w-8 text-ecommerce-primary mr-3" />
              <div className="flex-1">
                <p className="font-medium">{file.name}</p>
                <p className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(2)} KB
                </p>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={clearFile}
                className="ml-auto"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="mt-2">
              <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center hover:border-ecommerce-primary transition-colors cursor-pointer">
                <input
                  id="fileUpload"
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <Label htmlFor="fileUpload" className="cursor-pointer">
                  <Upload className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                  <span className="text-sm font-medium text-gray-900 block">
                    Click to upload CSV file
                  </span>
                  <span className="text-xs text-gray-500 block mt-1">
                    Supported format: CSV
                  </span>
                </Label>
              </div>
            </div>
          )}
        </div>

        <div className="mb-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Important Note</AlertTitle>
            <AlertDescription className="text-sm">
              <p>Please ensure your file follows these guidelines:</p>
              <ul className="list-disc pl-5 mt-2 space-y-1">
                <li>Required columns: name, description, price, image_url</li>
                <li>The image_url should be a direct URL to an image (starting with http:// or https://)</li>
                <li>Image URLs must be publicly accessible</li>
                <li>Price must be a positive number</li>
                <li><strong>Do not include the ID column</strong> in your data - IDs are automatically generated</li>
              </ul>
              <p className="mt-2 text-xs text-gray-500">
                Example CSV row: <br />
                "Product Name","Product description goes here",19.99,https://example.com/image.jpg
              </p>
            </AlertDescription>
          </Alert>
        </div>

        <div className="flex gap-2">
          <Button
            type="submit"
            className="bg-ecommerce-primary hover:bg-ecommerce-primary/90"
            disabled={isSubmitting || !file}
          >
            {isSubmitting ? "Uploading..." : "Upload Products"}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => onSuccess()}
          >
            Cancel
          </Button>
        </div>
      </form>

      {result && (
        <div className="mt-8">
          <h3 className="font-semibold text-lg mb-3">Upload Results</h3>
          
          <div className="flex gap-4 mb-4">
            <div className="flex-1 bg-green-50 border border-green-200 rounded-md p-4">
              <div className="flex items-center">
                <Check className="h-5 w-5 text-green-600 mr-2" />
                <span className="font-medium">Successful</span>
              </div>
              <p className="text-2xl font-bold mt-2">{result.success}</p>
            </div>
            
            <div className="flex-1 bg-red-50 border border-red-200 rounded-md p-4">
              <div className="flex items-center">
                <X className="h-5 w-5 text-red-600 mr-2" />
                <span className="font-medium">Failed</span>
              </div>
              <p className="text-2xl font-bold mt-2">{result.failed}</p>
            </div>
          </div>
          
          {result.failedProducts.length > 0 && (
            <div className="mt-4">
              <h4 className="font-medium mb-2">Failed Products</h4>
              <div className="max-h-60 overflow-y-auto border rounded-md">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Error</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {result.failedProducts.map((item, index) => (
                      <tr key={index}>
                        <td className="px-4 py-2 text-sm">
                          <div className="font-medium">{item.data.name || 'Unknown'}</div>
                          {item.data.price && <div className="text-xs text-gray-500">${item.data.price}</div>}
                        </td>
                        <td className="px-4 py-2 text-sm text-red-600">
                          {item.errors.join(', ')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BulkUploadForm;
