
import React from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
}) => {
  const pages = calculatePageNumbers(currentPage, totalPages);

  function calculatePageNumbers(current: number, total: number) {
    if (total <= 7) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }

    if (current <= 3) {
      return [1, 2, 3, 4, 5, "...", total];
    }

    if (current >= total - 2) {
      return [1, "...", total - 4, total - 3, total - 2, total - 1, total];
    }

    return [1, "...", current - 1, current, current + 1, "...", total];
  }

  if (totalPages <= 1) return null;

  return (
    <motion.div 
      className="flex justify-center items-center space-x-1"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <motion.div
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          variant="outline"
          size="icon"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className="h-9 w-9 shadow-sm hover:shadow transition-all duration-200"
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Previous page</span>
        </Button>
      </motion.div>

      {pages.map((page, index) => (
        <React.Fragment key={index}>
          {page === "..." ? (
            <span className="px-3 py-2">...</span>
          ) : (
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Button
                variant={currentPage === page ? "default" : "outline"}
                size="icon"
                onClick={() => typeof page === "number" && onPageChange(page)}
                className={`h-9 w-9 ${
                  currentPage === page ? 
                  "bg-gradient-to-r from-ecommerce-primary to-ecommerce-secondary hover:from-ecommerce-primary/90 hover:to-ecommerce-secondary/90 shadow" : 
                  "shadow-sm hover:shadow"
                } transition-all duration-200`}
              >
                {page}
              </Button>
            </motion.div>
          )}
        </React.Fragment>
      ))}

      <motion.div
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          variant="outline"
          size="icon"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className="h-9 w-9 shadow-sm hover:shadow transition-all duration-200"
        >
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Next page</span>
        </Button>
      </motion.div>
    </motion.div>
  );
};

export default Pagination;
