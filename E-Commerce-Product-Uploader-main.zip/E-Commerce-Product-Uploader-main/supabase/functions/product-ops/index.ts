
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { crypto } from "https://deno.land/std@0.168.0/crypto/mod.ts";

const supabaseUrl = "https://xyespnksmvsgrohyzggb.supabase.co";
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const supabase = createClient(supabaseUrl, supabaseKey);

// Cache object to store image hashes temporarily during bulk operations
// Using a more persistent structure with productId as values
const imageHashCache = new Map();

// Table to store image hashes permanently
const IMAGE_HASH_TABLE = 'product_image_hashes';

// Initialize the image hash table if it doesn't exist
async function ensureImageHashTable() {
  // Check if table exists
  const { data, error } = await supabase.rpc('check_table_exists', {
    table_name: IMAGE_HASH_TABLE
  }).single();
  
  if (error) {
    console.error("Error checking for table:", error);
    return false;
  }
  
  if (!data.exists) {
    // Create the table if it doesn't exist
    const { error: createError } = await supabase.rpc('create_image_hash_table');
    if (createError) {
      console.error("Error creating image hash table:", createError);
      return false;
    }
  }
  
  return true;
}

function generateCsvTemplate() {
  // Updated to include all required fields with proper formatting
  return 'name,description,price,image_url\nSample Product,This is a sample product description,19.99,https://example.com/sample.jpg';
}

// Parse CSV data into structured format
function parseCSV(csvContent) {
  const lines = csvContent.split('\n');
  const headers = lines[0].split(',').map(h => h.trim());
  const results = [];
  
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue;
    
    // Use a more robust CSV parsing approach to handle commas within fields
    const currentLine = lines[i].trim();
    const values = [];
    let insideQuotes = false;
    let currentValue = '';
    
    for (let j = 0; j < currentLine.length; j++) {
      const char = currentLine[j];
      
      if (char === '"' && (j === 0 || currentLine[j-1] !== '\\')) {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        values.push(currentValue.trim());
        currentValue = '';
      } else {
        currentValue += char;
      }
    }
    
    // Push the last value
    values.push(currentValue.trim());
    
    const product = {};
    headers.forEach((header, index) => {
      if (header && values[index] !== undefined) {
        // Handle the case where image field might map to image_url
        if (header === 'image') {
          product['image_url'] = values[index] ? values[index].trim() : '';
        } else {
          product[header] = values[index] ? values[index].trim() : '';
        }
      }
    });
    
    // Ensure image_url is set correctly
    if (product.image && !product.image_url) {
      product.image_url = product.image;
      delete product.image;
    }
    
    results.push(product);
  }
  
  return results;
}

// Function to validate image URL
async function validateImageUrl(url) {
  try {
    // Check if URL is valid
    new URL(url);
    
    // Check if the URL is using HTTP/HTTPS protocol (reject if it is)
    if (url.match(/^https?:\/\//i)) {
      return { isValid: false, reason: "Image URLs are not allowed, please upload an image file" };
    }
    
    return { isValid: true };
  } catch (error) {
    console.error("Invalid image URL:", error.message);
    return { isValid: false, reason: "Invalid image URL format" };
  }
}

// Function to generate a hash from image data
async function generateImageHash(base64Data) {
  try {
    // Remove data URL prefix if present
    const imageData = base64Data.includes('base64,') ? 
      base64Data.split('base64,')[1] : 
      base64Data;
      
    // Convert base64 to binary
    const binaryString = atob(imageData);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // Generate SHA-256 hash
    const hashBuffer = await crypto.subtle.digest('SHA-256', bytes.buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    
    return hashHex;
  } catch (error) {
    console.error("Error generating image hash:", error);
    throw error;
  }
}

// Check if an image is a duplicate by comparing its hash
async function checkDuplicateImage(imageData, productId = null) {
  try {
    // Generate image hash
    const hash = await generateImageHash(imageData);
    
    // Check for the hash in the database 
    const { data: existingProducts } = await supabase
      .from('products')
      .select('id, image_url')
      .filter('id', 'neq', productId || ''); // Exclude the current product if provided
    
    console.log("Checking for duplicates among", existingProducts?.length || 0, "existing products");
    
    // Check if any existing product already has this image
    const foundDuplicate = await Promise.all(
      (existingProducts || []).map(async (product) => {
        // Skip if no image_url or it doesn't contain base64 data
        if (!product.image_url) {
          return false;
        }
        
        try {
          // For base64 images
          if (product.image_url.includes('base64')) {
            const existingHash = await generateImageHash(product.image_url);
            return hash === existingHash;
          } 
          // For regular URLs, we'd need to fetch the image content first
          // This is a simplified check that just compares URLs
          else if (imageData === product.image_url) {
            return true;
          }
          return false;
        } catch (err) {
          console.error("Error comparing image hash:", err);
          return false;
        }
      })
    ).then(results => results.some(result => result));
    
    // Also check in temporary cache for bulk operations
    const duplicateInCache = imageHashCache.has(hash) && 
                           imageHashCache.get(hash) !== productId;
    
    // Store hash in cache (useful for bulk operations)
    if (!duplicateInCache && productId) {
      imageHashCache.set(hash, productId);
    }
    
    const isDuplicate = foundDuplicate || duplicateInCache;
    console.log("Duplicate check result:", isDuplicate ? "DUPLICATE FOUND" : "No duplicates");
    
    return { isDuplicate, hash };
  } catch (error) {
    console.error("Error checking duplicate image:", error);
    return { isDuplicate: false, error: error.message };
  }
}

// Process incoming product data for validation and processing
async function processProductData(data, userId = null) {
  const successProducts = [];
  const failedProducts = [];
  
  console.log("Processing products:", JSON.stringify(data));
  
  // Clear the hash cache at the beginning of a new batch
  imageHashCache.clear();
  
  // Process each product
  for (const item of data) {
    // Ensure we're using the correct field for image URL
    const imageUrl = item.image_url || item.image || "";
    
    const product = {
      name: item.name,
      description: item.description,
      price: parseFloat(item.price),
      // Use image_url from CSV
      image_url: imageUrl,
      created_by: userId
    };
    
    console.log("Processing product:", JSON.stringify(product));
    
    // Validate product data
    const validationErrors = [];
    
    if (!product.name || product.name.trim() === '') {
      validationErrors.push('Product name is required');
    }
    
    if (!product.description || product.description.trim() === '') {
      validationErrors.push('Product description is required');
    }
    
    if (!product.price) {
      validationErrors.push('Product price is required');
    } else if (isNaN(parseFloat(product.price)) || parseFloat(product.price) <= 0) {
      validationErrors.push('Product price must be a positive number');
    }
    
    // Validate image URL
    if (!product.image_url) {
      validationErrors.push('Product image URL is required');
    } else {
      // Check if the image URL is a valid format and not an HTTP/HTTPS URL
      const imageUrlValidation = await validateImageUrl(product.image_url);
      if (!imageUrlValidation.isValid) {
        validationErrors.push(imageUrlValidation.reason);
      } else if (product.image_url.includes('base64')) {
        // If it's a base64 image, check for duplicates
        const duplicateCheck = await checkDuplicateImage(product.image_url);
        if (duplicateCheck.isDuplicate) {
          validationErrors.push('This image is already used for another product');
        }
      }
    }
    
    if (validationErrors.length > 0) {
      failedProducts.push({
        data: product,
        errors: validationErrors
      });
    } else {
      successProducts.push(product);
    }
  }
  
  console.log(`Processing ${successProducts.length} valid products`);
  
  // Actually insert the products into the database if there are successful ones
  if (successProducts.length > 0) {
    try {
      const { data, error } = await supabase
        .from("products")
        .insert(successProducts);
        
      if (error) {
        console.error("Error inserting products:", error);
        // If there's a database error, move products to failed list
        for (const product of successProducts) {
          failedProducts.push({
            data: product,
            errors: ['Database error: ' + error.message]
          });
        }
        return {
          success: 0,
          failed: failedProducts.length,
          successProducts: [],
          failedProducts
        };
      }
      
      console.log("Inserted products successfully");
    } catch (err) {
      console.error("Exception during product insert:", err);
      // Handle unexpected errors
      for (const product of successProducts) {
        failedProducts.push({
          data: product,
          errors: ['Server error: ' + err.message]
        });
      }
      return {
        success: 0,
        failed: failedProducts.length,
        successProducts: [],
        failedProducts
      };
    }
  }
  
  return {
    success: successProducts.length,
    failed: failedProducts.length,
    successProducts,
    failedProducts
  };
}

// Function to store image hash in database for permanent storage
async function storeImageHash(hash, productId, imageUrl = null) {
  try {
    // First check if we need to create the table
    await ensureImageHashTable();
    
    // Then store the hash in our cache for immediate use
    imageHashCache.set(hash, productId);
    
    // And also in our database for permanent storage
    const { error } = await supabase
      .from(IMAGE_HASH_TABLE)
      .upsert([
        { 
          hash: hash, 
          product_id: productId,
          image_url: imageUrl || null,
          created_at: new Date().toISOString()
        }
      ], { 
        onConflict: 'hash',
        ignoreDuplicates: false
      });
    
    if (error) {
      console.error("Error storing image hash in database:", error);
      return false;
    }
    
    console.log(`Successfully stored hash ${hash} for product ${productId}`);
    return true;
  } catch (error) {
    console.error("Error storing image hash:", error);
    return false;
  }
}

// Function to retrieve all stored hashes from database
async function loadStoredHashes() {
  try {
    // Check if table exists first
    const tableExists = await ensureImageHashTable();
    if (!tableExists) return;
    
    // Load all hashes from database
    const { data, error } = await supabase
      .from(IMAGE_HASH_TABLE)
      .select('hash, product_id');
    
    if (error) {
      console.error("Error loading stored hashes:", error);
      return;
    }
    
    // Add all hashes to our cache
    if (data && data.length > 0) {
      console.log(`Loaded ${data.length} image hashes from database`);
      data.forEach(item => {
        imageHashCache.set(item.hash, item.product_id);
      });
    }
  } catch (error) {
    console.error("Error in loadStoredHashes:", error);
  }
}

// Handler for the check-duplicate-image action
async function handleCheckDuplicateImage(imageHash, currentProductId) {
  try {
    console.log("Checking duplicate image with hash:", imageHash);
    console.log("Current product ID:", currentProductId || "New product");
    
    // Load all stored hashes first
    await loadStoredHashes();
    
    // Check cache first for efficiency (useful during bulk operations)
    const cachedProductId = imageHashCache.get(imageHash);
    if (cachedProductId && cachedProductId !== currentProductId) {
      console.log("Found duplicate in cache for product ID:", cachedProductId);
      
      // Get product details
      const { data: productData } = await supabase
        .from('products')
        .select('name')
        .eq('id', cachedProductId)
        .single();
      
      return { 
        isDuplicate: true, 
        productId: cachedProductId,
        productName: productData?.name || 'Unknown product'
      };
    }
    
    // Check the database table directly
    try {
      // First ensure the table exists
      await ensureImageHashTable();
      
      // Then query it
      const { data: hashData, error: hashError } = await supabase
        .from(IMAGE_HASH_TABLE)
        .select('product_id')
        .eq('hash', imageHash)
        .neq('product_id', currentProductId || '')
        .single();
      
      if (!hashError && hashData) {
        const duplicateProductId = hashData.product_id;
        
        // Get product details
        const { data: productData } = await supabase
          .from('products')
          .select('name')
          .eq('id', duplicateProductId)
          .single();
        
        console.log(`Found duplicate in database for product: ${productData?.name || 'Unknown'} (${duplicateProductId})`);
        
        return {
          isDuplicate: true,
          productId: duplicateProductId,
          productName: productData?.name || 'Unknown product'
        };
      }
    } catch (dbError) {
      console.error("Error checking hash table:", dbError);
    }
    
    // If not found in cache or database, query the products table as a fallback
    // Query the database for all products except the current one being edited
    const { data: products, error } = await supabase
      .from('products')
      .select('id, name, image_url');
      
    if (error) {
      console.error("Database error while checking products:", error);
      throw error;
    }
    
    console.log(`Checking against ${products.length} products in database`);
    
    // Filter out the current product
    const otherProducts = products.filter(p => p.id !== currentProductId);
    
    // Check each product's image - this is more intensive but ensures accuracy
    for (const product of otherProducts) {
      if (!product.image_url) continue;
      
      try {
        let productImageHash;
        
        // For base64 images
        if (product.image_url.includes('base64')) {
          productImageHash = await generateImageHash(product.image_url);
        } 
        // For stored images, fetch and hash them
        else {
          try {
            // Try to fetch the image
            const response = await fetch(product.image_url);
            if (!response.ok) continue;
            
            const blob = await response.blob();
            const arrayBuffer = await blob.arrayBuffer();
            const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            productImageHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            
            // Store this hash in our database for future checks
            await storeImageHash(productImageHash, product.id, product.image_url);
          } catch (fetchError) {
            console.error(`Error fetching image for product ${product.id}:`, fetchError);
            continue;
          }
        }
        
        // Compare hashes
        if (productImageHash === imageHash) {
          console.log(`Found duplicate image for product: ${product.name} (${product.id})`);
          
          // Update cache for future checks
          await storeImageHash(imageHash, product.id, product.image_url);
          
          return {
            isDuplicate: true,
            productId: product.id,
            productName: product.name
          };
        }
      } catch (err) {
        console.error(`Error processing product ${product.id}:`, err);
      }
    }
    
    // If no duplicates found, store this hash for the current product
    if (currentProductId) {
      await storeImageHash(imageHash, currentProductId);
    }
    
    return { isDuplicate: false };
  } catch (error) {
    console.error("Error in handleCheckDuplicateImage:", error);
    return { 
      isDuplicate: false, 
      error: error.message 
    };
  }
}

// Handler for storing image hash
async function handleStoreImageHash(imageHash, productId, imageUrl) {
  try {
    console.log(`Storing hash ${imageHash} for product ${productId}`);
    const result = await storeImageHash(imageHash, productId, imageUrl);
    return { success: result };
  } catch (error) {
    console.error("Error in handleStoreImageHash:", error);
    return { success: false, error: error.message };
  }
}

serve(async (req) => {
  // Handle CORS for preflight requests
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  
  try {
    const url = new URL(req.url);
    const pathname = url.pathname;
    
    console.log("Handling request:", pathname);
    
    // Handle CSV template download
    if (pathname.endsWith("/template/csv")) {
      console.log("Generating CSV template");
      const csvContent = generateCsvTemplate();
      return new Response(csvContent, {
        headers: {
          ...corsHeaders,
          "Content-Type": "text/csv",
          "Content-Disposition": "attachment; filename=product_template.csv"
        }
      });
    }
    
    // Handle generic API requests with actions
    const requestBody = await req.json().catch(() => ({}));
    const action = requestBody.action;
    
    // Action: Check duplicate image
    if (action === "check-duplicate-image") {
      console.log("Processing check-duplicate-image action");
      const { imageHash, currentProductId } = requestBody;
      
      if (!imageHash) {
        return new Response(JSON.stringify({ error: "Image hash is required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
      
      const result = await handleCheckDuplicateImage(imageHash, currentProductId);
      
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }
    
    // Action: Store image hash
    else if (action === "store-image-hash") {
      console.log("Processing store-image-hash action");
      const { imageHash, productId, imageUrl } = requestBody;
      
      if (!imageHash || !productId) {
        return new Response(JSON.stringify({ error: "Image hash and product ID are required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
      
      const result = await handleStoreImageHash(imageHash, productId, imageUrl);
      
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }
    
    // Handle bulk product upload
    else if (pathname.endsWith("/products/bulk")) {
      if (req.method !== "POST") {
        return new Response(JSON.stringify({ error: "Method not allowed" }), {
          status: 405,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
      
      console.log("Processing bulk product upload");
      
      try {
        const formData = await req.formData();
        const productFile = formData.get("productFile");
        const userId = formData.get("userId");
        
        console.log("User ID from form data:", userId);
        
        if (!productFile) {
          return new Response(JSON.stringify({ error: "No file uploaded" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }
          });
        }
        
        console.log("File uploaded:", productFile.name, "type:", productFile.type);
        
        const fileContent = await productFile.text();
        let products = [];
        
        // Parse CSV data
        if (productFile.name.endsWith(".csv")) {
          products = parseCSV(fileContent);
        } else {
          return new Response(JSON.stringify({ error: "Unsupported file format. Please use CSV format." }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }
          });
        }
        
        console.log(`Parsed ${products.length} products from file`);
        console.log("First product sample:", JSON.stringify(products[0]));
        
        const results = await processProductData(products, userId);
        
        console.log(`Processing complete. Success: ${results.success}, Failed: ${results.failed}`);
        
        return new Response(JSON.stringify(results), {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      } catch (error) {
        console.error("Error processing upload:", error);
        return new Response(JSON.stringify({ error: error.message || "Failed to process upload" }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
    }
    
    return new Response(JSON.stringify({ error: "Not Found" }), {
      status: 404,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("Error:", error.message);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
});
